# SEG2105-Project
 On-Demand Home Repair Services App<br />
 Repository link:https://github.com/klahori/SEG2105-Project<br />
Repository link for CircleCI testing: https://github.com/klahori/seg2105-projectCircle<br />
 Group Members: Khyber Lahori, Abdullah Khalid, Osama-Al-Mazloum, Riyanson Alfred<br />
 For CircleCI we needed to use another repository since it wasnt able to be built here  due to constraints in circleCI the link to that repository can be found above also a picture showing the circleCI test succeeding can be found in the Deliverable2_submit folder under the name circleCI_proof<br/> 
 Admin can be created although we have already created one in our firebase database and no more then one admin for the app can be created<br />
**Email:** 123@gmail.com<br />
**Password:** 123123<br />
 **How to use services**
* login as an admin(email password provided above)
* hit the services button
* to add services enter a service name and the price per hour and hit the add button
* to update/ delete a service you must perform a long click on the service you wish to delete/ update until a pop up appears
* if you wish to delete the service simply hit delete
* if you wish to update the service enter the new service name and cost per hour and hit update even if you only want to change  one part of the service (either just the name or just the price) you will still need to retype the other in order to update it
