# SEG2105-Project
This is the main reposirtory for deliverable 4</br>
On-Demand Home Repair Services App </br>
CircleCI Repository link: https://github.com/klahori/seg2105-projectCircle</br>
Group Members: Khyber Lahori, Abdullah Khalid, Osama-Al-Mazloum, Riyanson Alfred </br>
HomeOwner email:1@gmail.com
Password: 123123
