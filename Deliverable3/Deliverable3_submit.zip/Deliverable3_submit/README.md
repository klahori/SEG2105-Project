# SEG2105-Project
 On-Demand Home Repair Services App<br />
 Repository link:https://github.com/klahori/SEG2105-Project<br />
Repository link for CircleCI testing: https://github.com/klahori/seg2105-projectCircle<br />
 Group Members: Khyber Lahori, Abdullah Khalid, Osama-Al-Mazloum, Riyanson Alfred<br />
Emulator used: Nexus 5X API 28<br/>

 Service Provider can be created although we have already created one in our firebase database you could still make another one if you wanted since we can have many service providers<br />
**Email:** 12@gmail.com<br />
**Password:** 123123<br />
 **How to use add/remove services**
* login as an Service Provider(email password provided above)
* hit the services button
* to add services hit the add a service button
* you will see a list of services admin had added
* from that list you will have to long click a service you want to provide
* after the long click you will get a pop up showing the service name and price per hour for that service simply hit add to add it to your services
* you will get a message that the service had been added note that you cannot add the same service to your list more than once
* click anywhere out side the pop up to get ride of the box
* and repeat to add an many services as the admin offers
* click the back button to go back there you will go back and see a list of the service that have been added to your profile 
* if you want to delete any of these services simply go to this page that shows the list of all your service 
* perfrom a long click on the service you want removoved
* a pop up will come showing the service you want to delete simply hit the delete button and the service will be removed from your profile
* once again hit anywhere outside the popup button to remove the popup
* once done adding/removing service to your profile you can hit the back button on the page with your services to go back to the welcome page<br />
 **How to use edit your profile**
* on the welcome page hit the profile button
* there you will see your phone number, address,company name , description,and a question wheather or not you are licenced 
* your phone number and address we got from the user when they signed up therefore those fields can be shown but not edited
* the company name is a field that must be filled
* the last two fields are optional but can be filled if the user wants to withe a desritpion and for the licence user cal only type in Yes or No<br />
 **How to  add availability**
 * in profile you can also add availability once on the page where you can edit your profile account simply hit the add availability button
 * you will get a calander pop up select the day you want to work however you cannot select a date in the past 
 * next select the time you want to start working
 * next select the time you will stop working
 * the availability has been added
 * to viw it go to your welcome page by hitting the back button<br />
  **How to update availability**
* on the welcome page you can see your availability 
* to edit this long click on the availability you want to edit
* a popup will come now click on the change date button to select a new date if you want the same date you must select the same day
* once the date has been selected you will get a message telling you the date you chose if that is the day you wanted simply hit confirm on the right of the change date button to confirm the date
* next select the start time and confirm that value  with the confirm button right of the change star time button
* same thing for changing end time hit the change end time button and once the time has been selected hit the confirm button to the right of the change end time button
* once all the dates and times have been confirmed you can hit the update button and the availiability will be updated<br />
  **How to delete availability**
* to delete an availability select the availability you wanted to delete on the welcome page by long clicking it
*a pop up will come showing the date of the availability you chose 
* simply hit the delete button to delete the availability
